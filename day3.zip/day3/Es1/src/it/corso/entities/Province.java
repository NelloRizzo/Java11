package it.corso.entities;

public class Province extends BaseEntity {
    private String name;
    private String acronym;
    private Region region;

    public Province() {
    }

    public Province(Long id, String name, String acronym, Region region) {
        super(id);
        this.name = name;
        this.acronym = acronym;
        this.region = region;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    @Override
    public String toString() {
        return String.format("Province{ id = %d, name = \"%s\", acronym = \"%s\", region = %s }", getId(), name, acronym, region);
    }
}
