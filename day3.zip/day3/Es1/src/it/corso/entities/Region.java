package it.corso.entities;

public class Region extends BaseEntity {
    private String name;
    private Area area;

    public Region() {
    }

    public Region(Long id, String name, Area area) {
        super(id);
        this.name = name;
        this.area = area;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return String.format("Region { id = %d, name = \"%s\", area = %s}", getId(), name, area);
    }
}
