package it.corso.entities;

public class City extends BaseEntity {
    private String name;
    private boolean capital;
    private String cadastral;
    private Province province;

    public City() {
    }

    public City(Long id, String name, boolean capital, String cadastral, Province province) {
        super(id);
        this.name = name;
        this.capital = capital;
        this.cadastral = cadastral;
        this.province = province;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isCapital() {
        return capital;
    }

    public void setCapital(boolean capital) {
        this.capital = capital;
    }

    public String getCadastral() {
        return cadastral;
    }

    public void setCadastral(String cadastral) {
        this.cadastral = cadastral;
    }

    public Province getProvince() {
        return province;
    }

    public void setProvince(Province province) {
        this.province = province;
    }

    @Override
    public String toString() {
        return String.format("City { id = %d, name = \"%s\", capital = %s, cadastral = \"%s\", province = %s }",
                getId(), name, capital ? "si" : "no", cadastral, province);
    }
}
