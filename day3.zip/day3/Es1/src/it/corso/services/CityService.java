package it.corso.services;

import it.corso.entities.City;
import it.corso.entities.Province;
import it.corso.entities.Region;

import java.util.List;

public interface CityService {
    List<City> getCities();

    List<City> getCitiesByProvince(String acronym);

    List<Province> getProvinces();

    List<Region> getRegions();

    List<Province> getProvincesByRegion(String region);

    long getCitiesCountByProvince(String acronym);

    long getCitiesCount();
}
