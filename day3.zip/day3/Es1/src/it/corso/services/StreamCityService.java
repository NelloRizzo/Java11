package it.corso.services;

import it.corso.entities.Area;
import it.corso.entities.City;
import it.corso.entities.Province;
import it.corso.entities.Region;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamCityService implements CityService {

    private final List<City> cities = new ArrayList<>();
    private final Charset charset;

    public StreamCityService(InputStream inputStream) {
        this(inputStream, Charset.defaultCharset());
    }

    public StreamCityService(InputStream inputStream, Charset charset) {
        this.charset = charset;
        load(inputStream);
    }

    public void load(InputStream stream) {
        cities.clear();
        try (var r = new BufferedReader(new InputStreamReader(stream, charset))) {
            cities.addAll(
                    r.lines()
                            .skip(3)
                            .map(l -> l.split(";"))
                            .map(a -> new City(
                                    Long.parseLong(a[15]),
                                    a[5],
                                    a[13].charAt(0) == 1,
                                    a[19],
                                    new Province(
                                            Long.parseLong(a[2]),
                                            a[11],
                                            a[14],
                                            new Region(
                                                    Long.parseLong(a[0]),
                                                    a[10],
                                                    new Area(
                                                            Long.parseLong(a[8]),
                                                            a[9]
                                                    )
                                            )
                                    )
                            ))
                            .collect(Collectors.toList())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<City> getCities() {
        return cities.stream()
                .collect(Collectors.toUnmodifiableList());
    }

    @Override
    public List<City> getCitiesByProvince(String acronym) {
        return cities.stream()
                .filter(c -> c.getProvince().getAcronym().equalsIgnoreCase(acronym))
                .collect(Collectors.toUnmodifiableList());
    }

    @Override
    public List<Province> getProvinces() {
        return cities.stream()
                .map(City::getProvince)
                .distinct()
                .collect(Collectors.toUnmodifiableList());
    }

    @Override
    public List<Region> getRegions() {
        return cities.stream()
                .map(c -> c.getProvince().getRegion())
                .distinct()
                .collect(Collectors.toUnmodifiableList());
    }

    @Override
    public List<Province> getProvincesByRegion(String region) {
        return cities.stream()
                .map(City::getProvince)
                .distinct()
                .filter(p -> p.getRegion().getName().equalsIgnoreCase(region))
                .collect(Collectors.toUnmodifiableList());
    }

    @Override
    public long getCitiesCountByProvince(String acronym) {
        return cities.stream()
                .filter(c -> c.getProvince().getAcronym().equalsIgnoreCase(acronym))
                .count();

    }

    @Override
    public long getCitiesCount() {
        return cities.size();
    }
}
