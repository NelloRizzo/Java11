package it.corso;

import it.corso.entities.Region;
import it.corso.services.CityService;
import it.corso.services.StreamCityService;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class Program {
    static void testService(CityService service) {
        System.out.format("In archivio sono presenti %d comuni\n", service.getCitiesCount());
        AtomicInteger count = new AtomicInteger(1);
        System.out.println("Eccoli:");
        service.getCities().forEach(c -> System.out.format("%04d\t%s\n", count.getAndIncrement(), c));
        System.out.println("Province italiane:");
        service.getProvinces().forEach(System.out::println);
        System.out.println("Regioni italiane:");
        service.getRegions().forEach(System.out::println);
        System.out.println("Ripartizioni geografiche italiane:");
        service.getRegions().stream().map(Region::getArea).distinct().forEach(System.out::println);
    }

    private static final String CITIES_URL = "https://www.istat.it/storage/codici-unita-amministrative/Elenco-comuni-italiani.csv";

    public static void main(String[] args) {
        try {
            var url = new URL(CITIES_URL);
            url.openConnection();
            testService(new StreamCityService(url.openConnection().getInputStream(), StandardCharsets.ISO_8859_1));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
