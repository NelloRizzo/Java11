import java.util.Arrays;

public class Application {
    public static void main(String[] args) {
        var people = Arrays.asList(
                new Person("Archimede", "Pitagorico"),
                new Person("Paperon", "De' Paperoni"),
                new Person("Pico", "De' Paperis"),
                new Person("Paperon", "De' Paperoni")
                );
        people.stream()
                //.map(p -> p.getSurname())
                .map(Person::getSurname)
                //.forEach(p -> System.out.println(p));
                .forEach(System.out::println);
        people.stream()
                //.map(p -> String.format("%c. %s", p.getName().charAt(0), p.getSurname()))
                //.filter(p -> p.length() <= 13)
                .sorted()
                .distinct()
                .forEach(System.out::println);
    }
}
