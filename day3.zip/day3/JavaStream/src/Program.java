import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class Program {
    public static void main(String[] args) {
        var a = new ArrayList<Integer>(Arrays.asList(12, 32, 3765, 467, 5489, 23456, 469, 59780, 34567, 9, 4858, 478, 32456, 2475));
        System.out.println("Esempio di lambda su Stream");
        a.stream().filter(i -> i % 2 == 0).forEach(i -> System.out.println(i));
        System.out.println("L'array è sempre quello originario");
        for (var i : a) System.out.println(i);
        System.out.println("Esempi:");
        var str = a.stream()
                .filter(obj -> obj % 2 != 0)
                .map(i -> String.format("Numero %d", i));

        a.add(-13);
        a.add(-40);

        //str.forEach(i -> System.out.println("Elemento: " + i));
        var nc = str.collect(Collectors.toList());
        System.out.println("Ottenimento di un'altra collection attraverso un Collector");
        nc.stream().forEach(c -> System.out.println(c));

        int div = 5;
        var first = a.stream().filter(n -> n % div == 0).findFirst();
        first.ifPresentOrElse(
                i -> System.out.println("Primo elemento divisibile per " + div + ": " + i),
                () -> System.out.println("Non ci sono numeri divisibili per " + div));
    }
}
