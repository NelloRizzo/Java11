import java.util.Random;
import java.util.stream.IntStream;

public class Samples {

    public static void main(String[] args) {
        final var r = new Random();
        var s = IntStream.range(0, 100)
                //.map(i -> r.nextInt(1000))
                .filter(i -> i < 250)
                .skip(10)
                .filter(i -> i % 2 == 0)
                .limit(150)
                //.forEach(System.out::println)
                ;
//        var sum = s.sum();
//        var min = s.min();
//        var max = s.max();

//        System.out.println(sum);
//        System.out.println(min);
//        System.out.println(max);
//        var first = s.findAny();
//        System.out.println(first);
//        var avg = s.average();
//        System.out.println(avg);
//        System.out.println(s.count());
//        System.out.println(s.reduce(1, (a, b) -> a * b)); // 10 * 11 * 12 * 13 * ... * 24
        System.out.println(s.mapToObj(i -> "" + i).reduce("[", (a, b) -> a + "|" + b));
    }
}
