package it.corso;

import it.corso.entities.GuestHouse;
import it.corso.services.GuestHouseService;
import it.corso.services.StreamGuestHouseService;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;

public class Program {
    static final String FILE_NAME = "./ricettive_roma.csv";

    static void handleGuestHouses(GuestHouseService service) {
        System.out.format("Totale posti letto a Roma: %d\n", service.getAll().stream().mapToLong(GuestHouse::getBeds).sum());
        System.out.println("Tipologie:");
        service.getAll().stream().map(GuestHouse::getKind).distinct().forEach(System.out::println);
        int skipped = 9;
        var first = service.getAll().stream().skip(skipped).findFirst().orElseThrow();
        System.out.format("Posizione del %d^ albergo %s: http://maps.google.com?q=Roma,%s",
                skipped,
                first.getName(),
                first.getAddress().replaceAll(" ", "+"));
    }

    public static void main(String[] args) throws FileNotFoundException {
        handleGuestHouses(new StreamGuestHouseService(new FileInputStream(FILE_NAME), StandardCharsets.ISO_8859_1));
    }
}
