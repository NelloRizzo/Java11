package it.corso.services;

import it.corso.entities.GuestHouse;
import it.corso.entities.Kind;
import it.corso.entities.Municipality;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamGuestHouseService implements GuestHouseService {
    private final Charset charset;
    private final List<GuestHouse> guestHouses = new ArrayList<>();

    public StreamGuestHouseService(InputStream inputStream, Charset charset) {
        this.charset = charset;
        load(inputStream);
    }

    public void load(InputStream inputStream) {
        guestHouses.clear();
        try (var r = new BufferedReader(new InputStreamReader(inputStream, charset))) {
            guestHouses.addAll(
                    r.lines()
                            .skip(1)
                            .map(l -> l.split(";"))
                            .map(a -> new GuestHouse(
                                    new Municipality(a[0]),
                                    new Kind(a[1], a[2]),
                                    a[3],
                                    a[4],
                                    Integer.parseInt(a[5]), // singole
                                    Integer.parseInt(a[6]), // doppie
                                    Integer.parseInt(a[7]), // triple
                                    Integer.parseInt(a[8]), // quadruple
                                    Integer.parseInt(a[9]), // quintuple
                                    Integer.parseInt(a[10]), // sestuple
                                    Integer.parseInt(a[11]), // camere
                                    Integer.parseInt(a[12]), // posti letto
                                    Integer.parseInt(a[13]), // unità abitative
                                    Integer.parseInt(a[14]) // posti letto per unità abitativa
                            ))
                            .collect(Collectors.toUnmodifiableList())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<GuestHouse> getAll() {
        return guestHouses.stream().collect(Collectors.toUnmodifiableList());
    }
}
