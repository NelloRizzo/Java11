package it.corso.services;

import it.corso.entities.GuestHouse;

import java.util.List;

public interface GuestHouseService {
    List<GuestHouse> getAll();
}
