package it.corso.entities;

import java.util.StringJoiner;

public class GuestHouse {
    private Municipality municipality;
    private Kind kind;
    private String name;
    private String address;
    private int singleRooms;
    private int doubleRooms;
    private int tripleRooms;
    private int familyRooms;
    private int quintupleRooms;
    private int sextupleRooms;
    private int rooms;
    private int beds;
    private int units;
    private int bedsPerUnit;

    public GuestHouse() {
    }

    public GuestHouse(Municipality municipality, Kind kind, String name, String address, int singleRooms, int doubleRooms, int tripleRooms, int familyRooms, int quintupleRooms, int sextupleRooms, int rooms, int beds, int units, int bedsPerUnit) {
        this.municipality = municipality;
        this.kind = kind;
        this.name = name;
        this.address = address;
        this.singleRooms = singleRooms;
        this.doubleRooms = doubleRooms;
        this.tripleRooms = tripleRooms;
        this.familyRooms = familyRooms;
        this.quintupleRooms = quintupleRooms;
        this.sextupleRooms = sextupleRooms;
        this.rooms = rooms;
        this.beds = beds;
        this.units = units;
        this.bedsPerUnit = bedsPerUnit;
    }

    public Municipality getMunicipality() {
        return municipality;
    }

    public void setMunicipality(Municipality municipality) {
        this.municipality = municipality;
    }

    public Kind getKind() {
        return kind;
    }

    public void setKind(Kind kind) {
        this.kind = kind;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSingleRooms() {
        return singleRooms;
    }

    public void setSingleRooms(int singleRooms) {
        this.singleRooms = singleRooms;
    }

    public int getDoubleRooms() {
        return doubleRooms;
    }

    public void setDoubleRooms(int doubleRooms) {
        this.doubleRooms = doubleRooms;
    }

    public int getTripleRooms() {
        return tripleRooms;
    }

    public void setTripleRooms(int tripleRooms) {
        this.tripleRooms = tripleRooms;
    }

    public int getFamilyRooms() {
        return familyRooms;
    }

    public void setFamilyRooms(int familyRooms) {
        this.familyRooms = familyRooms;
    }

    public int getQuintupleRooms() {
        return quintupleRooms;
    }

    public void setQuintupleRooms(int quintupleRooms) {
        this.quintupleRooms = quintupleRooms;
    }

    public int getSextupleRooms() {
        return sextupleRooms;
    }

    public void setSextupleRooms(int sextupleRooms) {
        this.sextupleRooms = sextupleRooms;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

    public int getBeds() {
        return beds;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }

    public int getUnits() {
        return units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public int getBedsPerUnit() {
        return bedsPerUnit;
    }

    public void setBedsPerUnit(int bedsPerUnit) {
        this.bedsPerUnit = bedsPerUnit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GuestHouse)) return false;

        GuestHouse that = (GuestHouse) o;

        if (!getName().equals(that.getName())) return false;
        return getAddress().equals(that.getAddress());
    }

    @Override
    public int hashCode() {
        int result = getName().hashCode();
        result = 31 * result + getAddress().hashCode();
        return result;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", GuestHouse.class.getSimpleName() + "[", "]")
                .add("municipality=" + municipality)
                .add("kind=" + kind)
                .add("name='" + name + "'")
                .add("address='" + address + "'")
                .add("singleRooms=" + singleRooms)
                .add("doubleRooms=" + doubleRooms)
                .add("tripleRooms=" + tripleRooms)
                .add("familyRooms=" + familyRooms)
                .add("quintupleRooms=" + quintupleRooms)
                .add("sextupleRooms=" + sextupleRooms)
                .add("rooms=" + rooms)
                .add("beds=" + beds)
                .add("units=" + units)
                .add("bedsPerUnit=" + bedsPerUnit)
                .toString();
    }
}
