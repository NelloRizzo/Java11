package it.corso.entities;

import java.util.StringJoiner;

public class Municipality {
    private String name;

    public Municipality() {
    }

    public Municipality(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Municipality)) return false;

        Municipality that = (Municipality) o;

        return getName().equalsIgnoreCase(that.getName());
    }

    @Override
    public int hashCode() {
        return getName().toLowerCase().hashCode();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Municipality.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .toString();
    }
}
