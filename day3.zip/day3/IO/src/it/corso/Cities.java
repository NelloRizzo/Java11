package it.corso;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class Cities {

    public static void main(String[] args) throws IOException {
        final String filename = "./elenco-comuni.csv";
        final var page = 0;
        final var pageSize = 8000;
        try (var r = new BufferedReader(new FileReader(filename, StandardCharsets.ISO_8859_1))) {
            final AtomicInteger count = new AtomicInteger(0);
            r.lines()
                    .skip(3)
                    .skip(page * pageSize)
                    .limit(pageSize)
                    .map(l -> l.split(";"))
                    .filter(l -> l[10].equalsIgnoreCase("piemonte"))
//                    .filter(l -> l[14].equalsIgnoreCase("MI"))
                    .map(l -> String.format("%s (%s)", l[5], l[14]))
                    .forEach(l -> {
                        System.out.format("%04d\t%s\n", count.incrementAndGet(), l);
                    });
        }
    }
}

