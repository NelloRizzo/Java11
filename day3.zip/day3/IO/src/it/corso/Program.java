package it.corso;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Program {

    public static void main(String[] args) {
        String text = "Questo è un testo che voglio gestire su un file del mio file system.";
        final String fileName = "./test.txt";
//        try (OutputStream out = new FileOutputStream(fileName)) {
//            out.write(text.getBytes(StandardCharsets.UTF_8));
////                out.close();
//        } catch (FileNotFoundException e) {
//            System.err.println("File not found");
//        } catch (IOException e) {
//            System.err.println("I/O Exception");
//        }
        OutputStream out;
        try {
            out = new FileOutputStream(fileName);
            try {
                out.write(text.getBytes(StandardCharsets.UTF_8));
//                out.close();
            } finally {
                out.close();
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println("I/O Exception");
        }
        try (InputStream in = new FileInputStream(fileName)) {
            var bytes = in.readAllBytes();
            System.out.println("Bytes letti " + bytes.length + ": " + Arrays.toString(bytes));
            System.out.println("Testo: ");
            var content = new String(bytes);
            System.out.println(content);
//                in.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println("I/O Exception");
        }


        try (Reader r = new FileReader(fileName, StandardCharsets.UTF_8)) {
            try (BufferedReader br = new BufferedReader(r)) {
                System.out.println(br.readLine());
//                    br.close();
            }
//                r.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println("I/O Exception");
        }
    }
}
