package it.corso;

import java.util.Random;

public class CloseableSample {

    private static class Closeable implements AutoCloseable {

        public Closeable() {
            System.out.println("Sto mettendo da parte le risorse necessarie per l'elaborazione.");
        }

        @Override
        public void close() throws Exception {
            System.out.println("Sto rilasciando le risorse messe da parte nel costruttore.");
        }
    }

    public static void operate() throws Exception {
        try (var c = new Closeable()) { // try-with-resources
            if (new Random().nextBoolean())
                throw new Exception("Ops, l'applicazione è terminata prima che sia stato richiamato il close()");
//            c.close();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Inizio dell'applicazione");
        try {
            operate();
        } catch (Exception e) {
            System.out.println("Ops... si è verificata un'eccezione");
        }
        System.out.println("L'applicazione continua");
    }
}
