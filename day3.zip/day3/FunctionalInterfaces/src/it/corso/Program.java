package it.corso;

import java.util.Random;

public class Program {

    static void sortAsc(Integer[] numbers) {
        for (var i = 0; i < numbers.length - 1; ++i)
            for (var j = i + 1; j < numbers.length; ++j)
                if (numbers[i] > numbers[j]) {
                    var t = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = t;
                }
    }

    static void sortDesc(Integer[] numbers) {
        for (var i = 0; i < numbers.length - 1; ++i)
            for (var j = i + 1; j < numbers.length; ++j)
                if (numbers[i] < numbers[j]) {
                    var t = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = t;
                }
    }


    static boolean mustSwapForSortAsc(int a, int b) {
        return a > b;
    }

    static void sortAscDelegated(Integer[] numbers) {
        for (var i = 0; i < numbers.length - 1; ++i)
            for (var j = i + 1; j < numbers.length; ++j)
                if (mustSwapForSortAsc(numbers[i], numbers[j])) {
                    var t = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = t;
                }
    }

    static boolean mustSwapForSortDesc(int a, int b) {
        return a < b;
    }

    static void sortDescDelegated(Integer[] numbers) {
        for (var i = 0; i < numbers.length - 1; ++i)
            for (var j = i + 1; j < numbers.length; ++j)
                if (mustSwapForSortDesc(numbers[i], numbers[j])) {
                    var t = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = t;
                }
    }

    static void sort(Integer[] numbers, Swapper swapper) { // Pattern: Template method
        for (var i = 0; i < numbers.length - 1; ++i)
            for (var j = i + 1; j < numbers.length; ++j)
                if (swapper.mustSwap(numbers[i], numbers[j])) {
                    var t = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = t;
                }
    }

    interface Swapper { // Interfaccia funzionale
        boolean mustSwap(int x, int y);
    }

    static class SwapperAsc implements Swapper {

        @Override
        public boolean mustSwap(int x, int y) {

            return x > y;
        }
    }

    static void print(String message, Integer[] a) {
        System.out.println(message);
        for (var i : a) System.out.println(i);
    }

    public static void main(String[] args) {
        Integer[] numbers = {34, 4536, 47568, 3657, 589, 21345, 54698, 44, 687, 95469, 1};
        print("Array iniziale", numbers);
        sortAsc(numbers);
        print("Array ordinato con sortAsc()", numbers);
        sortDesc(numbers);
        print("Array ordinato con sortDesc()", numbers);
        sortAscDelegated(numbers);
        print("Array ordinato con sortAscDelegated()", numbers);
        sortDescDelegated(numbers);
        print("Array ordinato con sortDescDelegated()", numbers);
        sort(numbers, new SwapperAsc());
        print("Array ordinato in senso crescente con sort() e SwapperAsc()", numbers);

        sort(numbers, new Swapper() { // classe anonima
            @Override
            public boolean mustSwap(int x, int y) {
                return x < y;
            }
        });
        print("Array ordinato in senso decrescente con sort() e classe anonima", numbers);

        //sort(numbers, (a, b) -> { return a < b; });
        sort(numbers, (a, b) -> a < b);
        print("Array ordinato in senso decrescente con sort() e notazione lambda", numbers);
        sort(numbers, (a, b) -> a % 2 == 0 ? a < b : a > b);
        print("Array ordinato con sort() e lambda 'strana'", numbers);

        boolean sortAscending = new Random().nextBoolean();
        sort(numbers, (i, j) -> sortAscending ? i > j : i < j);
        print("Array ordinato secondo le regole di una variabile\n'catturata' dalla lambda (asc = " + sortAscending + ")", numbers);
    }
}
