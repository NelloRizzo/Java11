import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Maps {
    public static void main(String[] args) {
        Map<Integer, String> is = new HashMap<>();
        is.put(1, "Uno");
        is.put(2, "Due");
        is.put(4, "Quattro");
        System.out.println("Keys:");
        for (var k : is.keySet()) {
            System.out.println(k);
        }
        System.out.println("Values:");
        for (var k : is.values()) {
            System.out.println(k);
        }
        System.out.println("item with key = 2: " + is.get(2));
        Map<String, Integer> si = new HashMap<>();
        si.put("Uno", 1);
        si.put("Due", 2);
        si.put("Quattro", 4);
        System.out.println("Keys:");
        for (var k : si.keySet()) {
            System.out.println(k);
        }
        System.out.println("Values:");
        for (var k : si.values()) {
            System.out.println(k);
        }
        System.out.println("item with key = Due: " + si.get("Due"));

        Map<Integer, Employee> ie  = new HashMap<>();
        ie.put(1234, new Employee("Paperino", 1, LocalDate.now()));
        ie.put(1234, new Employee("Paperone", 3, LocalDate.now()));
        ie.put(424, new Employee("Paperone", 3, LocalDate.now()));
        System.out.println("Keys:");
        for (var k : ie.keySet()) {
            System.out.println(k);
        }
        System.out.println("Values:");
        for (var k : ie.values()) {
            System.out.println(k);
        }
        System.out.println("item with key = 1234: " + ie.get(1234));
    }
}
