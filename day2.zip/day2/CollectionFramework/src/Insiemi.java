import java.util.*;

public class Insiemi {
    public static <T> void print(String message, Collection<T> collection) {
        System.out.println(message);
        System.out.println("\tDimensione attuale della collection: " + collection.size());
        for (var i : collection) {
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        Set<My> mines = new HashSet<>();
        mines.add(new My(10));
        mines.add(new My(20));
        mines.add(new My(10));
        mines.add(new My(40));
        print("Mines", mines);

        Queue<My> qm = new ArrayDeque<>();
        qm.offer(new My(10));
        qm.offer(new My(20));
        qm.offer(new My(30));
        print("Queue", qm);
        System.out.println("Consumazione di una coda");
        while (!qm.isEmpty())
            System.out.println(qm.poll());
    }
}
