import java.time.LocalDate;

public class Employee implements Comparable<Employee> {
    private String name;
    private int id;
    private LocalDate hiringDate;

    public Employee(String name, int id, LocalDate hiringDate) {
        this.name = name;
        this.id = id;
        this.hiringDate = hiringDate;
    }

    public Employee() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getHiringDate() {
        return hiringDate;
    }

    public void setHiringDate(LocalDate hiringDate) {
        this.hiringDate = hiringDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;

        Employee employee = (Employee) o;

        if (!getName().equals(employee.getName())) return false;
        return getHiringDate().equals(employee.getHiringDate());
    }

    @Override
    public int hashCode() {
        int result = getName().hashCode();
        result = 31 * result + getHiringDate().hashCode();
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Employee{");
        sb.append("name='").append(name).append('\'');
        sb.append(", id=").append(id);
        sb.append(", hiringDate=").append(hiringDate);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(Employee o) {
        //if (id < o.id) return -1; else if (id == o.id) return 0; else return 1;
        //return name.compareTo(o.name);
        return hiringDate.compareTo(o.hiringDate);
    }
}
