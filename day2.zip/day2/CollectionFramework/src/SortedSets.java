import java.time.LocalDate;
import java.util.Set;
import java.util.TreeSet;

public class SortedSets {

    public static void main(String[] args) {
        Set<Integer> ts = new TreeSet<>();
        ts.add(123);
        ts.add(253);
        ts.add(32);
        for (var i : ts)
            System.out.println(i);

        Set<Employee> te = new TreeSet<>();
        te.add(new Employee("Paperino", 10, LocalDate.now().minusMonths(10)));
        te.add(new Employee("Paperone", 1, LocalDate.now()));
        te.add(new Employee("Topolino", 100, LocalDate.now().minusMonths(8)));
        te.add(new Employee("Archimede", 40, LocalDate.now().plusDays(10)));
        for (var i : te)
            System.out.println(i);
    }
}
