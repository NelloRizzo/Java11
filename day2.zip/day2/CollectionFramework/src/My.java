import java.util.Objects;

public class My {
    private int value;

    public My(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "My(" + value + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof My) {
            My other = (My) obj;
            return other.value == this.value;
        }
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value);
    }
}
