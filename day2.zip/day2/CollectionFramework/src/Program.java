import java.util.ArrayList;
import java.util.Collection;

public class Program {
    public static void main(String[] args) {
        Collection<Integer> collection = new ArrayList<>();
        collection.add(1);
        collection.add(34);
        collection.add(2);
        System.out.println("Collection iniziale, dimensione attuale: " + collection.size());
        for (var i : collection) {
            System.out.println(i);
        }
        System.out.println("Dopo la remove");
        collection.remove(34);
        for (var i : collection) {
            System.out.println(i);
        }

    }
}
