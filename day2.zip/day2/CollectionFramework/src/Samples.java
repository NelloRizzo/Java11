import java.time.LocalDate;
import java.util.*;

public class Samples {

    public static <T> void print(String message, Collection<T> coll) {
        System.out.println(message);
        System.out.println("\tItems: " + coll.size());
        for (var i : coll) System.out.println(i);
    }

    public static void main(String[] args) {
        var archimede = new Employee("Archimede Pitagorico", 1, LocalDate.now().minusWeeks(30));
        var pico = new Employee("Pico De' Paperis", 2, LocalDate.now().minusYears(2));
        var paperone = new Employee("Paperon De' Paperoni", 3, LocalDate.now().minusDays(30));

        Deque<Employee> se = new ArrayDeque<>();
        se.push(archimede);
        se.push(pico);
        se.push(paperone);
        print("Stack of employees", se);
        se.pop();
        print("Stack of employees after pop()", se);
        System.out.println("Next candidate for pop: " + se.peek());
        print("Stack of employees after peek()", se);

        se.clear();
        se.offer(archimede);
        se.offer(pico);
        se.offer(paperone);
        print("Queue of employees", se);
        se.poll();
        print("Queue after poll()", se);

        List<Employee> le = new ArrayList<>();
        le.add(archimede);
        le.add(paperone);
        le.add(1, pico);
        print("List of employees", le);
        System.out.println("Second element: " + le.get(1));
        le.remove(archimede);
        print("Remove by object", le);
        le.remove(0);
        print("Remove first element", le);
        le.clear();
        le.add(archimede);
        le.add(paperone);
        le.add(1, pico);
        print("Sublist(1,3)", le.subList(1, 3));

        System.out.println("Navigation by iterator");
        var it = le.iterator();
        while (it.hasNext())
            System.out.println(it.next());

        for (var i : le)
            System.out.println(i);
    }
}
