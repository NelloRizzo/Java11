import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

public class EqualsEcc {
    public static <T> void print(String message, Collection<T> collection) {
        System.out.println(message);
        System.out.println("\tDimensione attuale della collection: " + collection.size());
        for (var i : collection) {
            System.out.println(i);
        }
    }

    public static class My {
        private int value;

        public My(int value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "My(" + value + ")";
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof My){
                My other = (My)obj;
                return other.value == this.value;
            }
            return super.equals(obj);
        }
    }

    public static void main(String[] args) {
        Collection<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(3);
        numbers.add(5);
        numbers.add(6);
        print("Collection iniziale", numbers);
        numbers.remove(6);
        print("Rimosso il numero 6", numbers);
        ArrayList<My> mines = new ArrayList<>();
        mines.add(new My(10));
        mines.add(new My(30));
        mines.add(new My(40));
        mines.add(new My(50));
        print("Collection di My", mines);
        mines.remove(new My(50));
        mines.add(1, new My(245));
        print("Tentativo di rimuovere My(50)", mines);
        System.out.println("Terzo elemento: " + mines.get(2));

        My m1 = new My(10);
        My m2 = new My(10);
        if (m1.equals(m2))
            System.out.println("m1 ed m2 sono uguali");
        else
            System.out.println("m1 ed m2 sono diversi");
        My m3 = m2;
        if (m3 == m2)
            System.out.println("m3 ed m2 sono uguali");
        else
            System.out.println("m3 ed m2 sono diversi");
    }
}
