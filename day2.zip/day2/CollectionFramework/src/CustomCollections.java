import javax.annotation.processing.SupportedSourceVersion;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class CustomCollections {

    public static class MyIterable implements Iterator<Character> , Iterable<Character>{

        private final String text;

        public MyIterable(String text) {
            this.text = text;
        }

        int current = 0;

        @Override
        public boolean hasNext() {
            return current < text.length();
        }

        @Override
        public Character next() {
            return Character.toUpperCase(text.charAt(current++));
        }

        @Override
        public Iterator<Character> iterator() {
            current = 0;
            return this;
        }
    }

    public static class MyList extends ArrayList<String> {
        @Override
        public boolean add(String s) {
            return super.add(s.toUpperCase());
        }
    }
    public static void main(String[] args) {
        var m = new MyIterable("Ciao a tutti");
        for(var i: m)
            System.out.println(i);

        var l = new MyList();
        l.add("pippo");
        l.add("pluto");
        l.add("PaPeRiNo");
        for(var i: l)
            System.out.println(i);
    }
}
