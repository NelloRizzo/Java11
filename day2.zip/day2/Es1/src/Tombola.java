import java.util.Arrays;

/**
 * Occorre simulare l'estrazione dei numeri della tombola.
 * In pratica si deve produrre un algoritmo che sia in grado di proporre casualmente un numero da 1 a 90
 * senza ripetizioni.
 */
public class Tombola {

    public static void main(String[] args) {
        var bag = new NumbersBag();
        System.out.println("Numeri da 1 a 90");
        for (var i : bag) {
            System.out.println(i);
        }
        bag = new NumbersBag(-10, 20);
        System.out.println("Numeri da -10 a 10, disordinati");
        bag.shuffle();
        for (var i : bag) {
            System.out.println(i);
        }
        bag = new NumbersBag(Arrays.asList(3, 2534, 37, 45, 876, 645, 9678, 63));
        System.out.println("Sacchetto riempito con numeri custom");
        for (var i : bag) {
            System.out.println(i);
        }
        System.out.println("Estrazione dei numeri della tombola");
        bag = new NumbersBag();
        bag.shuffle();
//      var i = bag.iterator();
//      while (i.hasNext())
//          System.out.println(i.next());
        for (Integer integer : bag) System.out.println(integer);
    }
}
