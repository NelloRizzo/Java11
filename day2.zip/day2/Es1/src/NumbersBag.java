import java.util.*;

/**
 * Un "sacchetto" pieno di numeri.
 */
public class NumbersBag implements Iterable<Integer> {
    /**
     * I numeri nel sacchetto.
     */
    private final List<Integer> numbers;

    /**
     * Inizializza un sacchetto con i numeri da 1 a 90.
     */
    public NumbersBag() {
        this(90);
    }

    /**
     * Inizializza un sacchetto con una sequenza di numeri a partire da 1.
     * @param count totale dei numeri da inserire nel sacchetto.
     */
    public NumbersBag(int count) {
        this(1, count);
    }

    /**
     * Inizializza un sacchetto con una sequenza di numeri.
     * @param start primo numero.
     * @param count totale dei numeri da inserire.
     */
    public NumbersBag(int start, int count) {
        numbers = new ArrayList<>(count);
        for (int i = 0; i < count; ++i) numbers.add(start + i);
    }

    /**
     * Inizializza un sacchetto inserendo al suo interno un insieme di numeri.
     * @param numbers i numeri da inserire nel sacchetto.
     */
    public NumbersBag(Collection<Integer> numbers){
        this.numbers = new ArrayList<>();
        this.numbers.addAll(numbers);
    }

    /**
     * Mescola i numeri nel sacchetto.
     */
    public void shuffle() {
        Collections.shuffle(numbers);
    }

    /**
     * Serve per iterare nel sacchetto nell'ordine con il quale i numeri sono inseriti.
     * @return l'iteratore sui numeri.
     */
    @Override
    public Iterator<Integer> iterator() {
        return numbers.iterator();
    }
}
