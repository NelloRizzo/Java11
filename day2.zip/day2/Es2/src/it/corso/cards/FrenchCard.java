package it.corso.cards;

/**
 * Una carta da gioco francese.
 */
public class FrenchCard extends Card {
    /**
     * I semi delle carte da gioco francesi.
     */
    public enum Seeds {HEARTS, DIAMONDS, CLUBS, SPADES}

    /**
     * Valore associato al jolly.
     */
    private static final int JOKER_VALUE = 15;
    /**
     * Seme utilizzato per differenziare il jolly rosso.
     */
    private static final Seeds RED_JOKER_SEED = Seeds.HEARTS;
    /**
     * Seme utilizzato per differenziare il jolly nero.
     */
    private static final Seeds BLACK_JOKER_SEED = Seeds.SPADES;

    /**
     * Istanza di jolly rosso.
     */
    public static final FrenchCard RED_JOKER = new FrenchCard(RED_JOKER_SEED.ordinal(), JOKER_VALUE);
    /**
     * Istanza di jolly nero.
     */
    public static final FrenchCard BLACK_JOKER = new FrenchCard(BLACK_JOKER_SEED.ordinal(), JOKER_VALUE);

    private FrenchCard(int seed, int value) {
        super(seed, value);
    }

    /**
     * Ottiene il seme.
     * @return il seme definito nell'enumerazione dei semi delle carte francesi.
     */
    public Seeds getFrenchSeed() {
        return Seeds.values()[getSeed()];
    }

    @Override
    public String toString() {
        if (getValue() == JOKER_VALUE) return getFrenchSeed() == RED_JOKER_SEED ? "RED JOKER" : "BLACK JOKER";
        final var values = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        return String.format("%s of %s", values[getValue() - 1], getFrenchSeed());
    }

    /**
     * Builder per carte francesi.
     */
    public static class Builder {
        /**
         * Memorizza il seme della carta da costruire.
         */
        private Seeds seed;
        /**
         * Memorizza il valore della carta da costruire.
         */
        private int value;

        /**
         * Imposta il seme della carta da costruire.
         * @param seed il seme della carta.
         * @return un riferimento al builder stesso per favorire la concatenazione delle chiamate
         */
        public Builder withSeed(Seeds seed) {
            this.seed = seed;
            return this;
        }

        /**
         * Imposta il valore della carta da costruire.
         * @param value il valore della carta.
         * @return un riferimento al builder stesso per favorire la concatenazione delle chiamate
         */
        public Builder withValue(int value) {
            this.value = value;
            return this;
        }

        /**
         * Costruisce una carta francese.
         * @return la carta francese con valore e seme impostato attraverso gli altri metodi.
         */
        public FrenchCard build() {
            // controlla che il valore sia consentito
            if (value < 1 || value > 13)
                throw new RuntimeException("Value is out of range");
            // solo se il valore è corretto crea la carta
            return new FrenchCard(seed.ordinal(), value);
        }
    }
}
