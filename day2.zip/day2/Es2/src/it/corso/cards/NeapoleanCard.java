package it.corso.cards;

/**
 * Una carta da gioco napoletana.
 * Si tratta di una CARTA DA GIOCO (appartiene alla famiglia delle carte da gioco)
 * ma è una entità che ESISTE realmente, perché posso dare un senso alle informazioni
 * veicolate, in quanto, a differenza della CARTA DA GIOCO astratta, il seme è caratterizzato
 * da informazioni reali e il valore è limitato all'intervallo [1-10].
 */
public class NeapoleanCard extends Card {

    public enum Seeds {DENARI, COPPE, SPADE, BASTONI}

    private NeapoleanCard(int seed, int value) {
        super(seed, value);
    }

    public Seeds getNeapoleanSeed() {
        return Seeds.values()[getSeed()];
    }

    @Override
    public String toString() {
        if (getValue() == 7 && getNeapoleanSeed() == Seeds.DENARI) return "settebello";
        final var values = new String[]{"asso", "due", "tre", "quattro", "cinque", "sei", "sette", "donna", "cavallo", "re"};
        return String.format("%s di %s", values[getValue() - 1], getNeapoleanSeed().toString().toLowerCase());
    }

    public static class Builder {
        /**
         * Memorizza il seme della carta da creare.
         */
        private Seeds seed;
        /**
         * Memorizza il valore della carta da creare.
         */
        private int value;

        /**
         * Imposta il seme della carta da creare.
         * @param seed il seme della carta da creare.
         * @return un riferimento al builder per consentire una notazione fluente.
         */
        public Builder withSeed(Seeds seed) {
            this.seed = seed;
            return this;
        }

        /**
         * Imposta il valore della carta da creare.
         * @param value il valore della carta da creare.
         * @return un riferimento al builder per consentire una notazione fluente.
         */
        public Builder withValue(int value) {
            this.value = value;
            return this;
        }

        /**
         * Crea la carta napoletana con il seme e il valore impostati tramite
         * i metodi withXXXX().
         * @return la carta napoletana.
         */
        public NeapoleanCard build() {
            if (value < 1 || value > 10) throw new RuntimeException("Value is out of range");
            return new NeapoleanCard(seed.ordinal(), value);
        }
    }
}
