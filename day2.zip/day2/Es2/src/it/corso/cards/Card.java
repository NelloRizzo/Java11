package it.corso.cards;

/**
 * "Idea" di carta da gioco.
 * Una "carta da gioco" NON ESISTE, ma esiste solo la sua idea, ecco perché è astratta.
 */
public abstract class Card {
    /**
     * Memorizza il seme della carta come intero.
     */
    private final int seed;
    /**
     * Memorizza il valore della carta.
     */
    private final int value;

    /**
     * Costruttore.
     * @param seed seme.
     * @param value valore.
     */
    protected Card(int seed, int value) {
        this.seed = seed;
        this.value = value;
    }

    /**
     *
     * @return legge il seme.
     */
    public int getSeed() {
        return seed;
    }

    /**
     *
     * @return legge il valore.
     */
    public int getValue() {
        return value;
    }
}
