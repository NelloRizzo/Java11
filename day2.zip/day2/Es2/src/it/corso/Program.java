package it.corso;

import it.corso.decks.FrenchDeck;
import it.corso.decks.NeapoleanDeck;

public class Program {

    public static void main(String[] args) {
        var nd = new NeapoleanDeck();
        System.out.println("Mazzo di carte napoletane:");
        for (var c : nd)
            System.out.println(c);
        var fd = new FrenchDeck();
        System.out.println("Mazzo di carte francesi:");
        for (var c : fd)
            System.out.println(c);
        fd.shuffle();
        System.out.println("Mazzo di carte francesi mescolato:");
        for (var c : fd)
            System.out.println(c);
    }
}
