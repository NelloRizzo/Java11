package it.corso.decks;

import it.corso.cards.NeapoleanCard;

public class NeapoleanDeck extends Deck<NeapoleanCard> {
    public NeapoleanDeck() {
        super(40);

        final var b = new NeapoleanCard.Builder();
        for (NeapoleanCard.Seeds s : NeapoleanCard.Seeds.values())
            for (var v = 1; v < 11; ++v)
                cards.add(b.withValue(v).withSeed(s).build());
    }
}
