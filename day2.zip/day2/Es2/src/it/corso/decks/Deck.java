package it.corso.decks;

import it.corso.cards.Card;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Un mazzo di carte.
 * @param <T> il tipo di carta presente nel mazzo (notare che vanno bene tutti i tipi T a patto
 *           che estendano la classe Card: T extends Card - si chiama varianza del tipo generico)
 */
public abstract class Deck<T extends Card> implements Iterable<T> {
    /**
     * Le carte presenti nel mazzo.
     * Si tratta di una variabile protected perché essa dovrà essere utilizzata nelle sottoclassi
     * per creare effettivamente le carte a seconda del tipo di mazzo.
     */
    protected final List<T> cards;

    protected Deck(int totalCards) {
        // l'inizializzazione con il totale delle carte ottimizza la gestione della memoria.
        cards = new ArrayList<>(totalCards);
    }

    /**
     * Mescola il mazzo di carte.
     */
    public void shuffle() {
        Collections.shuffle(cards);
    }

    /**
     * @return l'iteratore sulle carte.
     */
    @Override
    public Iterator<T> iterator() {
        return cards.iterator();
    }
}
