package it.corso.decks;

import it.corso.cards.FrenchCard;

/**
 * Un mazzo di carte francesi.
 */
public class FrenchDeck extends Deck<FrenchCard> {
    public FrenchDeck() {
        // ci sono 54 carte!
        super(54);
        final var b = new FrenchCard.Builder();
        for (FrenchCard.Seeds s : FrenchCard.Seeds.values())
            for (var v = 1; v < 14; ++v)
                // tramite il builder creo le 52 carte
                cards.add(b.withValue(v).withSeed(s).build());
        // aggiungo il jolly nero
        cards.add(FrenchCard.BLACK_JOKER);
        // aggiungo il jolly rosso
        cards.add(FrenchCard.RED_JOKER);
    }
}
