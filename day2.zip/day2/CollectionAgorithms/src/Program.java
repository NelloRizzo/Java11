import java.util.*;

public class Program {
    static <T> void print(String message, Collection<T> c) {
        System.out.println(message);
        System.out.println("\tsize: " + c.size());
        for (var i : c) System.out.println(i);
    }

    public static void main(String[] args) {
        var list = new ArrayList<Integer>();
        final var random = new Random(12345);
        for (var i = 0; i < 10; i++) list.add(random.nextInt());
        print("Lista iniziale", list);
        Collections.sort(list);
        print("Lista ordinata", list);
        Collections.shuffle(list);
        print("Lista 'disordinata':", list);
        System.out.println("Elemento più grande: " + Collections.max(list));
        System.out.println("Elemento più piccolo: " + Collections.min(list));
        Collections.rotate(list, 3);
        print("Rotazione con distanza = 3", list);
        var index = Collections.binarySearch(list, 1553932502);
        if (index < 0)
            System.out.println("Elemento non trovato");
        else
            System.out.println("Elemento trovato in posizione " + index);

        var l = Arrays.asList(new Integer[]{321, 432, 3456, 34567, 2364, 4875, 5324, 876543});
        var a = l.toArray(new Integer[]{});
    }
}
