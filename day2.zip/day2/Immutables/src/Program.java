import static java.lang.System.out;

public class Program {

    public static class Base {
        private final int value;
        private final Base ref;

        private int number;

        public int getNumber() {
            return number;
        }

        public void setNumber(int number) {
            this.number = number;
        }

        public Base() {
            value = 15;
            ref = new Base();
        }

        public void print() {
            ref.setNumber(1234);
            ref.setNumber(5235);
            out.println("Hello from Base");
        }
    }

    public static class Derived extends Base {
        @Override
        public void print() {
            super.print();
            out.println("\tand from Derived");
        }

        public final void finalPrint() {
            out.println("derivedPrint() is final!");
        }
    }

    public static final class ImmutableDerived extends Derived {
        @Override
        public void print() {
            super.print();
            out.println("\tImmutable overrides print() from Derived");
        }

//   IMPOSSIBILE perché derivedPrint è "final"
//        @Override
//        public void derivedPrint(){
//        }

    }

//    IMPOSSIBILE perché ImmutableDerived è "final"
//    public static class ImmutableDerivation extends ImmutableDerived {
//
//    }

    public static void main(String[] args) {
        //var b = new Base();
        Base b = new Base();
        var d = new Derived();
        // d = 10; // impossibile perché d è di tipo Derived!!!
        var id = new ImmutableDerived();
        b.print();
        d.print();
        id.print();
        id.finalPrint();
    }
}
