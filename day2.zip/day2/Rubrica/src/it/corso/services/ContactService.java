package it.corso.services;

import it.corso.entities.contacts.Contact;

public interface ContactService {
    void addContact(Contact c);
    Iterable<Contact> getAll();
    void deleteContact(Contact c);
}
