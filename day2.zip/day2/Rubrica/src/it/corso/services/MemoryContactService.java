package it.corso.services;

import it.corso.entities.contacts.Contact;
import it.corso.entities.contacts.ContactBook;

import java.util.Arrays;

public class MemoryContactService implements ContactService {
    private final ContactBook contacts;

    public MemoryContactService() {
        contacts = new ContactBook();
    }

    @Override
    public void addContact(Contact c) {
        contacts.add(c);
    }

    @Override
    public Iterable<Contact> getAll() {
        return Arrays.asList(contacts.toArray(new Contact[]{}));
    }

    @Override
    public void deleteContact(Contact c) {
        contacts.remove(c);
    }
}
