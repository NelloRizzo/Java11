package it.corso.entities.deliveries;

public class Website extends Delivery {
    private String address;

    public Website(String address) {
        this();
        this.address = address;
    }

    public Website() {
        super(false);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Website)) return false;

        Website website = (Website) o;

        return getAddress() != null ? getAddress().equals(website.getAddress()) : website.getAddress() == null;
    }

    @Override
    public int hashCode() {
        return getAddress() != null ? getAddress().hashCode() : 0;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Website{");
        sb.append("address='").append(address).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
