package it.corso.entities.deliveries;

public class PhoneNumber extends Delivery {
    private String phone;

    public PhoneNumber(String phone) {
        this();
        this.phone = phone;
    }

    public PhoneNumber() {
        super(false);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PhoneNumber)) return false;

        PhoneNumber that = (PhoneNumber) o;

        return phone.equals(that.phone);
    }

    @Override
    public int hashCode() {
        return phone.hashCode();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PhoneNumber{");
        sb.append("phone='").append(phone).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
