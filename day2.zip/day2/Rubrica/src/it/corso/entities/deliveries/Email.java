package it.corso.entities.deliveries;

public class Email extends Delivery {
    private String email;

    public Email(String email) {
        this();
        this.email = email;
    }

    public Email() {
        super(false);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Email)) return false;

        Email email1 = (Email) o;

        return getEmail() != null ? getEmail().equals(email1.getEmail()) : email1.getEmail() == null;
    }

    @Override
    public int hashCode() {
        return getEmail() != null ? getEmail().hashCode() : 0;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Email{");
        sb.append("email='").append(email).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
