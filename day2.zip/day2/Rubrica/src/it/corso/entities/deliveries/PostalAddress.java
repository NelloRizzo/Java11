package it.corso.entities.deliveries;

public class PostalAddress extends Delivery {
    private String street;
    private String city;
    private String country;
    private String zip;

    public PostalAddress(String street, String city, String country, String zip) {
        this();
        this.street = street;
        this.city = city;
        this.country = country;
        this.zip = zip;
    }

    public PostalAddress() {
        super(false);
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PostalAddress)) return false;

        PostalAddress that = (PostalAddress) o;

        if (!getStreet().equals(that.getStreet())) return false;
        return getZip().equals(that.getZip());
    }

    @Override
    public int hashCode() {
        int result = getStreet().hashCode();
        result = 31 * result + getZip().hashCode();
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PostalAddress{");
        sb.append("street='").append(street).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", country='").append(country).append('\'');
        sb.append(", zip='").append(zip).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
