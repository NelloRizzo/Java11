package it.corso.entities.deliveries;

public abstract class Delivery {
    private boolean business;

    public Delivery(boolean business) {
        this.business = business;
    }

    public boolean isBusiness() {
        return business;
    }

    public void setBusiness(boolean business) {
        this.business = business;
    }
}
