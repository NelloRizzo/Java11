package it.corso.entities.contacts;

import it.corso.entities.deliveries.Delivery;

import java.util.ArrayList;
import java.util.List;

public class Contact {
    private String name;
    private String surname;
    private String friendlyName;
    private final List<Delivery> deliveries = new ArrayList<>();

    public Contact(String name, String surname, String friendlyName) {
        this.name = name;
        this.surname = surname;
        this.friendlyName = friendlyName;
    }

    public Contact() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFriendlyName() {
        return friendlyName;
    }

    public void setFriendlyName(String friendlyName) {
        this.friendlyName = friendlyName;
    }

    public List<Delivery> getDeliveries() {
        return deliveries;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;

        Contact contact = (Contact) o;

        if (!getName().equals(contact.getName())) return false;
        if (getSurname() != null ? !getSurname().equals(contact.getSurname()) : contact.getSurname() != null)
            return false;
        return getFriendlyName() != null ? getFriendlyName().equals(contact.getFriendlyName()) : contact.getFriendlyName() == null;
    }

    @Override
    public int hashCode() {
        int result = getName().hashCode();
        result = 31 * result + (getSurname() != null ? getSurname().hashCode() : 0);
        result = 31 * result + (getFriendlyName() != null ? getFriendlyName().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Contact{");
        sb.append("name='").append(name).append('\'');
        sb.append(", surname='").append(surname).append('\'');
        sb.append(", friendlyName='").append(friendlyName).append('\'');
        sb.append(", deliveries=").append(deliveries);
        sb.append('}');
        return sb.toString();
    }
}
