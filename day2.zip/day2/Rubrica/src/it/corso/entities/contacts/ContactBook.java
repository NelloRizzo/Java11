package it.corso.entities.contacts;

import java.util.HashSet;

public class ContactBook extends HashSet<Contact> {

}
