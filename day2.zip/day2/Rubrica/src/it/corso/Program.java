package it.corso;

import it.corso.entities.contacts.Contact;
import it.corso.entities.deliveries.Email;
import it.corso.entities.deliveries.PostalAddress;
import it.corso.entities.deliveries.Website;
import it.corso.services.ContactService;
import it.corso.services.MemoryContactService;

public class Program {
    static void manageContacts(ContactService service) {
        var archimede = new Contact("Archimede", "Pitagorico", "archi");
        var paperone = new Contact("Paperon", "De' Paperoni", "paperone");
        var pico = new Contact("Pico", "De' Paperis", "pico");

        service.addContact(pico);
        service.addContact(archimede);
        service.addContact(paperone);
        service.addContact(pico); // si tratta di un set, quindi non sono accettati duplicati

        archimede.getDeliveries().add(new Email("archimede@pitagorico.math"));
        paperone.getDeliveries().add(new PostalAddress("via del Deposito, 44", "Paperopoli", "PP", "$$$$$"));
        pico.getDeliveries().add(new Website("http://www.prof.pico.net"));
        archimede.getDeliveries().add(new PostalAddress("via della Scienza, 314", "Paperopoli", "PP", "31415"));

        System.out.println("Contatti:");
        for (var c : service.getAll())
            System.out.println(c);
        System.out.println("Elimino paperone:");
        service.deleteContact(paperone);
        for (var c : service.getAll())
            System.out.println(c);
    }

    public static void main(String[] args) {
        manageContacts(new MemoryContactService());
    }
}
