import java.time.LocalDate;
import java.util.ArrayList;

public class CollectionFramework {
    public static void main(String[] args) {
        var names = new ArrayList<String>();
        names.add("Paperino");
        names.add("Topolino");
        names.add("Archimede");

        String sum = "";
        for (var i : names) {
            sum += i;
            System.out.println(i);
        }
        System.out.println(sum);

        var numbers = new ArrayList<Integer>();
        numbers.add(1);
        numbers.add(3);
        numbers.add(432);
        numbers.add(5151);
        int ns = 0;
        for(var i:numbers){
            ns+= i;
        }
        System.out.println(ns);
    }
}
