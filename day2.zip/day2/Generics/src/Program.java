import java.time.LocalDate;

public class Program {

//    public static void print(int[] a) {
//        for (var i : a) {
//            System.out.println(i);
//        }
//    }

//    public static void print(String[] a) {
//        for (var i : a) {
//            System.out.println(i);
//        }
//    }
//
//    public static void print(LocalDate[] a) {
//        for (var i : a) {
//            System.out.println(i);
//        }
//    }

    public static <Tipo> void print(Tipo[] a) {
        System.out.println("print() con generic " + a.getClass().getSimpleName());
        for (Tipo i : a) {
            System.out.println(i);
        }
    }

    public static class Pair<F, S> {
        public F first;
        public S second;
    }

    public static class OldPair{
        public Object first;
        public Object second;
    }


    public static void main(String[] args) {
        final Integer[] numbers = {1, 4325, 43567, 56789, 2354, 79865, 7890, 3456, 657809, 367};
        final String[] names = {"Paperino", "Topolino", "Pippo", "Archimede"};
        print(numbers);
        print(names);
        final LocalDate[] dates = {LocalDate.now(), LocalDate.of(1900, 1, 1), LocalDate.now().plusDays(5)};
        print(dates);
        var psd = new Pair<String, LocalDate>();
        psd.first = "Topolino";
        psd.second = LocalDate.now();
        var pds = new Pair<LocalDate, String>();
        pds.first = LocalDate.now();
        pds.second = "Paperino";
        var op = new OldPair();
        op.first = 15;
        op.first = "Topolino";
    }
}
