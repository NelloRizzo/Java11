package it.corso.fiscalcode.services;

import it.corso.fiscalcode.models.Area;
import it.corso.fiscalcode.models.City;
import it.corso.fiscalcode.models.Province;
import it.corso.fiscalcode.models.Region;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CitiesLoader {

    private int linesToSkip = 3;

    public int getLinesToSkip() {
        return linesToSkip;
    }

    public CitiesLoader setLinesToSkip(int linesToSkip) {
        this.linesToSkip = linesToSkip;
        return this;
    }

    private static class Constants {
        static final int CITY_ID = 15;
        static final int CITY_NAME = 5;
        static final int CITY_CAPITAL = 13;
        static final int CITY_CADASTRAL = 19;
        static final int PROVINCE_ID = 2;
        static final int PROVINCE_NAME = 11;
        static final int PROVINCE_ACRONYM = 14;
        static final int REGION_ID = 0;
        static final int REGION_NAME = 10;
        static final int AREA_ID = 8;
        static final int AREA_NAME = 9;
    }

    public List<City> getFromPath(Path path) {
        try {
            return getFromCSV(Files.readAllLines(path).stream().collect(Collectors.toUnmodifiableList()));
        } catch (Exception e) {
            System.err.println(e);
            return new ArrayList<>();
        }
    }

    public List<City> getFromStream(InputStream s) {
        try (var r = new BufferedReader(new InputStreamReader(new BufferedInputStream(s)))) {
            return getFromCSV(r.lines().collect(Collectors.toUnmodifiableList()));
        } catch (IOException e) {
            System.err.println(e);
            return new ArrayList<>();
        }
    }

    public List<City> getFromHttp(String url) {
        try {
            var client = HttpClient.newHttpClient();
            var request = HttpRequest.newBuilder(URI.create(url)).build();
            var response = client.send(request, HttpResponse.BodyHandlers.ofLines());
            return getFromCSV(response.body().collect(Collectors.toUnmodifiableList()));
        } catch (Exception e) {
            System.err.println(e);
            return new ArrayList<>();
        }
    }

    public List<City> getFromHttpAsync(String url) {
        try {
            var client = HttpClient.newHttpClient();
            var request = HttpRequest.newBuilder(URI.create(url)).build();
            return client.sendAsync(request, HttpResponse.BodyHandlers.ofLines())
                    .thenApply(HttpResponse::body)
                    .thenApply(l -> l.collect(Collectors.toUnmodifiableList()))
                    .thenApply(this::getFromCSV)
                    .get(); // attenzione! qui è come se operassimo in modalità sincrona
        } catch (Exception e) {
            System.err.println(e);
            return new ArrayList<>();
        }
    }

    public List<City> getFromCSV(List<String> csvLines) {
        return new ArrayList<City>(
                csvLines.stream()
                        .skip(linesToSkip)
                        .map(l -> l.split(";"))
                        .map(a -> new City(
                                Long.parseLong(a[Constants.CITY_ID]),
                                a[Constants.CITY_NAME],
                                a[Constants.CITY_CAPITAL].charAt(0) == 1,
                                a[Constants.CITY_CADASTRAL],
                                new Province(
                                        Long.parseLong(a[Constants.PROVINCE_ID]),
                                        a[Constants.PROVINCE_NAME],
                                        a[Constants.PROVINCE_ACRONYM],
                                        new Region(
                                                Long.parseLong(a[Constants.REGION_ID]),
                                                a[Constants.REGION_NAME],
                                                new Area(
                                                        Long.parseLong(a[Constants.AREA_ID]),
                                                        a[Constants.AREA_NAME]
                                                )
                                        )
                                )
                        )).collect(Collectors.toUnmodifiableList())
        );
    }
}
