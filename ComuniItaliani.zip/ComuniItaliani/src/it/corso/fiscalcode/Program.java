package it.corso.fiscalcode;

import org.apache.commons.lang.StringEscapeUtils;

import it.corso.fiscalcode.models.Area;
import it.corso.fiscalcode.models.City;
import it.corso.fiscalcode.models.Province;
import it.corso.fiscalcode.models.Region;
import it.corso.fiscalcode.services.CitiesLoader;
import jakarta.persistence.Persistence;

public class Program {

	public static void main(String[] args) {
		final var cities = new CitiesLoader().setLinesToSkip(3)
				.getFromHttp("https://www.istat.it/storage/codici-unita-amministrative/Elenco-comuni-italiani.csv");
		System.out.format("Caricate %d città", cities.size());

		try (final var em = Persistence.createEntityManagerFactory("Italian-Cities").createEntityManager()) {
			var t = em.getTransaction();
			t.begin();
			cities.stream() //
					.map(c -> c.getProvince().getRegion().getArea()).distinct() //
					.forEach(em::persist);
			cities.stream() //
					.map(c -> c.getProvince().getRegion()).distinct()//
					.forEach(r -> {
						System.out.println(r);
						var a = em.find(Area.class, r.getArea().getId());
						r.setName(StringEscapeUtils.escapeJava(r.getName()));
						r.setArea(a);
						em.persist(r);
					});
			cities.stream() //
					.map(City::getProvince).distinct() //
					.forEach(p -> {
						System.out.println(p);
						var r = em.find(Region.class, p.getRegion().getId());
						p.setName(StringEscapeUtils.escapeJava(p.getName()));
						p.setRegion(r);
						em.persist(p);
					});
			cities.stream() //
					.forEach(c -> {
						System.out.println(c);
						var p = em.find(Province.class, c.getProvince().getId());
						c.setName(StringEscapeUtils.escapeJava(c.getName()));
						c.setProvince(p);
						em.persist(c);
					});
			t.commit();
			
			System.out.println(em.find(City.class, 1011));
		}
	}

}
