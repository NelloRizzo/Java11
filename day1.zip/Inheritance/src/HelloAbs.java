public abstract class HelloAbs implements HelloInt{
    private String name;

    public String getName() {
        return name == null ? "World" : name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public abstract void greet();
//    {
//       System.out.println("Qui non so come salutare " + getName());
//    }
}
