public class Hello {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Hello() {

    }

    public Hello(String name) {
        this.name = name;
    }

    public void greet() {
        System.out.println("Hello, " + (name == null ? "World" : name));
    }
}
