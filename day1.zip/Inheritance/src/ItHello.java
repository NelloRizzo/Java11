public class ItHello extends HelloAbs {
    @Override
    public void greet() {
        System.out.println("Ciao, " + getName());
    }
}
