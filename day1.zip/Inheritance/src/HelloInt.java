public interface HelloInt {
    void greet();
}
