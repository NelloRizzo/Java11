public class Program {
    public static void mySystem(Hello h) {
        h.greet();
    }

    public static void myGreetingSystem(HelloInt h){
        h.greet();
    }
    public static void main(String[] args) {
//        Hello h1 = new Hello();
//        Hello h2 = new Hello("Nello");
//
//        mySystem(h1);
//        mySystem(h2);
//
//        HelloNew n = new HelloNew("it");
//        n.setName("Topolino");
//        n.greet();
//        n.newGreet();
//
//        LocalTime d = LocalTime.now();
//        if (d.getHour() >= 14)
//            mySystem(n);
//        else
//            mySystem(h2);

//        HelloAbs a = new HelloAbs();
//        a.setName("Nello");
//        myGreetingSystem(a);
        ItHello i = new ItHello();
        i.setName("Topolino");
        EnHello e = new EnHello();
        e.setName("Paperino");
        myGreetingSystem(i);
        myGreetingSystem(e);
    }
}
