public class HelloNew extends Hello {

    private String lang;

    public HelloNew() {
        lang = "it";
    }

    public HelloNew(String lang) {
        this.lang = lang;
    }

    public void newGreet() {
        if (lang == "it") System.out.print("Ciao, ");
        else System.out.print("Hello, ");
        System.out.println(getName());
    }

    @Override
    public void greet() {
        super.greet();
        System.out.println("\tLingua = " + lang);
    }
}
