public class EnHello extends HelloAbs{
    @Override
    public void greet() {
        System.out.println("Hello, " + getName());
    }
}
