public class My {
    /*
    private view:
        int value;
        int getValue();
        void setValue();

     public view:
        int getValue();
        void setValue();
     */

    private int value;

    public My() {
        value = 30;
    }

    public My(int start){
        value = start;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        if (value % 2 == 0)
            this.value = value - 1;
        else
            this.value = value;
    }
}
