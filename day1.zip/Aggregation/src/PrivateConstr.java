public class PrivateConstr {
    private int value;

    public int getValue() {
        return value;
    }

    private PrivateConstr() {
        value = 10;
    }

    public static class Builder {
        public PrivateConstr build(int value) {
            PrivateConstr p = new PrivateConstr();
            p.value = value;
            return p;
        }
    }
}
