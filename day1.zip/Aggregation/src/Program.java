import static java.lang.System.out;
public class Program {
    public static void main(String[] args) {
        My my = new My();

        //my.value = 10;
        my.setValue(11);

        My my2 = new My();
        //my2.value = 20;
        my2.setValue(20);

        My my3 = new My();
        My my4 = new My(35);
        //out.println(my.value);
        out.println(my.getValue());
        //out.println(my2.value);
        out.println(my2.getValue());
        out.println(my3.getValue());
        out.println(my4.getValue());

        //PrivateConstr c = new PrivateConstr();
        PrivateConstr c =  new PrivateConstr.Builder().build(40);
        out.println(c.getValue());


        Ratio.Builder b = new Ratio.Builder()
                .withDenominator(0).withNumerator(3);
        Ratio r = b.build();
        Ratio u = Ratio.getInstance();
    }
}
