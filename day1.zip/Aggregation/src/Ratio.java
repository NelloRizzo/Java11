public class Ratio {
    private int numerator;
    private int denominator;

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    private Ratio(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    private static Ratio _uno;
    public static Ratio getInstance() {
        if (_uno == null) _uno = new Ratio(1,1);
        return _uno;
    }

    public static class Builder {
        private int numerator;
        private int denominator;

        public Builder withNumerator(int n) {
            numerator = n;
            return this;
        }

        public Builder withDenominator(int d) {
            if (d == 0) throw new RuntimeException("Denominatore non può essere 0");
            denominator = d;
            return this;
        }

        public Ratio build() {
            if (denominator == 0) throw new RuntimeException("Denominatore non può essere 0");
            return new Ratio(numerator, denominator);
        }
    }
}
