public class Program {

    public static void PostOffice(User u){
        u.showFiscalCode();
    }
    public static void FootballParty(Fan f) {
        f.showFanBadge();
    }
    public static void main(String[] args) {
        Person archimede = new Person("Archimede", "Pitagorico");
        archimede.show();
        PostOffice(archimede);
        FootballParty(archimede);

        PostOffice(new User() {
            @Override
            public void showFiscalCode() {
                System.out.println("Sono un oggetto anonimo");
            }
        });
        PostOffice(() -> System.out.println("Sono un oggetto anonimo"));
    }
}
