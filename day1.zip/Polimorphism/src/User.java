public interface User {
    void showFiscalCode();
}
