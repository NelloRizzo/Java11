public interface Fan {
    void showFanBadge();
}
