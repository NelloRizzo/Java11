public class Person implements Fan, User {
    private String name;
    private String surname;

    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public void show() {
        System.out.println(name + " " + surname);
    }

    @Override
    public void showFanBadge() {
        show();
        System.out.println("\tTessera del Tifoso n. 12345");
    }

    @Override
    public void showFiscalCode() {
        show();
        System.out.println("\fCodice Fiscale: XXXXXX00X00X000X");
    }
}
