package it.corso.canvas;

import it.corso.shapes.Point;

/**
 * Canovaccio per il disegno di figure.
 */
public interface Canvas {
    int getWidth();
    int getHeight();
    void setPoint(Point p);
    void resetPoint(Point p);
    void line(Point p1, Point p2);
    boolean isOn(Point p);
}
