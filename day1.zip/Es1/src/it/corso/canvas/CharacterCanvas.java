package it.corso.canvas;

import it.corso.shapes.Point;

public class CharacterCanvas implements Canvas {
    private final boolean grid[][];
    private final int width;
    private final int height;

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public CharacterCanvas(int width, int height) {
        this.height = height;
        this.width = width;
        grid = new boolean[height][];
        for (int r = 0; r < height; ++r) {
            grid[r] = new boolean[width];
        }
    }

    @Override
    public void setPoint(Point p) {
        grid[p.getY()][p.getX()] = true;
    }

    @Override
    public void resetPoint(Point p) {
        grid[p.getY()][p.getX()] = true;
    }

    @Override
    public void line(Point p1, Point p2) {
        int x1 = p1.getX(), y1 = p1.getY();
        int x2 = p2.getX(), y2 = p2.getY();
        if (x1 == x2) {
            int miny = Math.min(y1, y2);
            int maxy = Math.max(y1, y2);
            for (int y = miny; y <= maxy; ++y) {
                setPoint(new Point(x1, y));
            }
        } else {
            int minx = Math.min(x1, x2);
            int maxx = Math.max(x1, x2);
            float m = (1f * y1 - y2) / (x1 - x2);
            float q = (1f * x1 * y2 - x2 * y1) / (x1 - x2);
            for (int x = minx; x <= maxx; ++x) {
                float y = m * x + q;
                setPoint(new Point(x, (int) y));
            }
        }
    }

    @Override
    public boolean isOn(Point p) {
        return grid[p.getY()][p.getX()];
    }
}
