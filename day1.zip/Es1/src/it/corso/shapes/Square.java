package it.corso.shapes;

public class Square extends Rectangle {
    public Square(int x1, int y1, int side) {
        super(x1, y1, x1 + side, y1 + side);
    }

    public Square(Point topLeft, int side) {
        super(topLeft.getX(), topLeft.getY(), topLeft.getX() + side, topLeft.getY() + side);
    }
}
