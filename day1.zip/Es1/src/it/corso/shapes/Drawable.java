package it.corso.shapes;

import it.corso.canvas.Canvas;

/**
 * Definizione di un elemento "disegnabile".
 */
public interface Drawable {
    void draw(Canvas c);
}
