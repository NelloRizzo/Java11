package it.corso.shapes;

import it.corso.canvas.Canvas;

/**
 * Figura geometrica in grado di "disegnare" se stessa su un canovaccio.
 */
public abstract class Shape implements Drawable {
    /**
     * Perimetro di contenimento della figura geometrica.
     */
    protected Boundary boundary;

    public Shape(int x1, int y1, int x2, int y2) {
        this(new Boundary(x1, y1, x2, y2));
    }

    public Shape(Boundary boundary) {
        this.boundary = boundary;
    }

    @Override
    public abstract void draw(Canvas c);
}
