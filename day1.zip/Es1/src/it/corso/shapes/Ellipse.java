package it.corso.shapes;

import it.corso.canvas.Canvas;

public class Ellipse extends Shape {
    private Point center;
    private int radiusX;
    private int radiusY;

    public Ellipse(int centerX, int centerY, int radiusX, int radiusY) {
        super(new Boundary(centerX - radiusX, centerY - radiusY, centerX + radiusX, centerY + radiusY));
        this.center = new Point(centerX, centerY);
        this.radiusX = radiusX;
        this.radiusY = radiusY;
    }

    public Ellipse(Point center, int radiusX, int radiusY) {
        this(center.getX(), center.getY(), radiusX, radiusY);
    }

    @Override
    public void draw(Canvas c) {
        for (float a = 0.1f; a <= 6.3; a += .1f) {
            c.setPoint(new Point(
                    center.getX() + (int) (Math.cos(a) * radiusX),
                    center.getY() + (int) (Math.sin(a) * radiusY)));
        }
    }
}
