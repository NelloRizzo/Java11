package it.corso.shapes;

public class Circle extends Ellipse {
    public Circle(int centerX, int centerY, int radius) {
        super(centerX, centerY, radius, radius);
    }

    public Circle(Point center, int radius) {
        super(center, radius, radius);
    }
}
