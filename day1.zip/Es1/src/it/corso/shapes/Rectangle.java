package it.corso.shapes;

import it.corso.canvas.Canvas;

public class Rectangle extends Shape {
    public Rectangle(int x1, int y1, int x2, int y2) {
        super(x1, y1, x2, y2);
    }

    public Rectangle(Boundary boundary) {
        super(boundary);
    }

    @Override
    public void draw(Canvas c) {
        c.line(boundary.getTopLeft(), boundary.getTopRight());
        c.line(boundary.getTopLeft(), boundary.getBottomLeft());
        c.line(boundary.getBottomLeft(), boundary.getBottomRight());
        c.line(boundary.getTopRight(), boundary.getBottomRight());
    }
}
