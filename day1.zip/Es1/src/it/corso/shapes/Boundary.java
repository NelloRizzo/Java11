package it.corso.shapes;

/**
 * Perimetro di una figura geometrica.
 */
public class Boundary {
    private int x1, y1, x2, y2;

    public Boundary(int x1, int y1, int x2, int y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public int getWidth() {
        return Math.abs(x1 - x2);
    }

    public int getHeight() {
        return Math.abs(y1 - y2);
    }

    public Point getFirst() {
        return new Point(x1, y1);
    }

    public Point getSecond() {
        return new Point(x2, y2);
    }

    public Point getTopLeft() {
        int minx = Math.min(x1, x2);
        int miny = Math.min(y1, y2);
        return new Point(minx, miny);
    }

    public Point getTopRight() {
        int miny = Math.min(y1, y2);
        int maxx = Math.max(x1, x2);
        return new Point(maxx, miny);
    }

    public Point getBottomRight() {
        int maxx = Math.max(x1, x2);
        int maxy = Math.max(y1, y2);
        return new Point(maxx, maxy);
    }

    public Point getBottomLeft() {
        int minx = Math.min(x1, x2);
        int maxy = Math.max(y1, y2);
        return new Point(minx, maxy);
    }
}
