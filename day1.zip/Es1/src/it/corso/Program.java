package it.corso;

import it.corso.canvas.Canvas;
import it.corso.canvas.CharacterCanvas;
import it.corso.shapes.*;

public class Program {
    public static void showCharCanvas(CharacterCanvas canvas) {
        for (int r = 0; r < canvas.getHeight(); ++r) {
            for (int c = 0; c < canvas.getWidth(); ++c) {
                System.out.print(canvas.isOn(new Point(c, r)) ? "*" : " ");
            }
            System.out.println();
        }
    }

    public static void drawingSystem(Canvas c) {
        new Rectangle(2, 2, 10, 10).draw(c);
        new Square(2, 2, 5).draw(c);
        new Line(2,2,10,10).draw(c);
        new Ellipse(20,10,10,5).draw(c);
        new Circle(20,10,5).draw(c);
    }

    public static void main(String[] args) {

        CharacterCanvas c = new CharacterCanvas(80, 23);
        drawingSystem(c);
//        ImageCanvas i = new ImageCanvas(800, 230);
//        drawingSystem(i);

        showCharCanvas(c);
    }
}
