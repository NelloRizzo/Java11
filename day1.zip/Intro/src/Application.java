import static java.lang.System.out;

public class Application {

    public static class Constants {
        public static final String MESSAGE = "Ciao";
    }

    int multiplier = 2;

    public class My {

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value * multiplier;
        }

        int value;

    }

    public static class Test {
        public static class Constants {
            public static final String MESSAGE = "Hello";
        }

        int value;
    }

    public static void main(String[] args) {
        out.println("Hello, World!");

        Application app = new Application();
        {
            My my = app.new My();
            app.multiplier = 10;
            my.setValue(10);
            out.println("my.value = " + my.value);
        }
        out.println("Application$My è scaricata dalla memoria");

        Test t = new Test();
        t.value = 10;
        out.println("t.value = " + t.value);

        out.println(Application.Constants.MESSAGE);
        out.println(Application.Test.Constants.MESSAGE);
    }
}
