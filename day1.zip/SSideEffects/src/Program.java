import static java.lang.System.*;
public class Program {

    public static void increment(int i){
        out.println("In entrata, i = " + i);
        i++;
        out.println("In uscita, i = " + i);
    }

    public static  class My{
        int value;
    }

    public static void increment(My m){
        out.println("In entrata, m.value = " + m.value);
        m.value++;
        out.println("In uscita, i = " + m.value);
    }
    public static void main(String[] args) {
//        int number = 10;
//        out.println("In main, number = " + number);
//        increment(number);
//        out.println("Dopo la chiamata ad increment, number = " + number);
        My number = new My(); number.value = 10;
        out.println("In main, number = " + number.value);
        increment(number);
        out.println("Dopo la chiamata ad increment, number = " + number.value);
    }
}
