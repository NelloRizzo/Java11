package it.corso.models;

import java.time.LocalDate;

/**
 * Dati anagrafici di una persona.
 */
public class PersonalData {
    private String firstName;
    private String lastName;
    private LocalDate birthday;
    private String birthCity;
    private Gender gender;

    public PersonalData() {
    }

    public PersonalData(String firstName, String lastName, LocalDate birthday, String birthCity, Gender gender) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
        this.birthCity = birthCity;
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public PersonalData setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public PersonalData setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public PersonalData setBirthday(LocalDate birthday) {
        this.birthday = birthday;
        return this;
    }

    public String getBirthCity() {
        return birthCity;
    }

    public PersonalData setBirthCity(String birthCity) {
        this.birthCity = birthCity;
        return this;
    }

    public Gender getGender() {
        return gender;
    }

    public PersonalData setGender(Gender gender) {
        this.gender = gender;
        return this;
    }

    @Override
    public String toString() {
        return new StringBuilder("PersonalData{")
                .append("firstName='").append(firstName).append('\'')
                .append(", lastName='").append(lastName).append('\'')
                .append(", birthday=").append(birthday)
                .append(", birthCity='").append(birthCity).append('\'')
                .append(", gender=").append(gender)
                .append('}')
                .toString();
    }
}
