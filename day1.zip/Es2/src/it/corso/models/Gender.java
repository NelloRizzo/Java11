package it.corso.models;

/**
 * Sesso di una persona.
 */
public enum Gender {
    /**
     * Uomo.
     */
    Male(0),
    /**
     * Donna.
     */
    Female(40);

    /**
     * Usato per associare al sesso il valore all'interno del codice fiscale.
     */
    public final int fiscalCodeValue;

    /**
     * Costruttore della enum.
     * @param fiscalCodeValue valore associato alla enum per il codice fiscale.
     */
    Gender(int fiscalCodeValue) {
        this.fiscalCodeValue = fiscalCodeValue;
    }
}
