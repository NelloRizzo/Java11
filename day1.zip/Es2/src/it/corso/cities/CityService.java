package it.corso.cities;

/**
 * Servizio di gestione delle città all'interno del contesto per il calcolo del codice fiscale.
 */
public interface CityService {
    /**
     * Dato il nome della città restituisce il codice catastale associato.
     * @param city Nome della città.
     * @return il codice catastale della città in input.
     */
    String getCadastral(String city);
}
