package it.corso.cities;

/**
 * Implementazione elementare del servizio di gestione delle città.
 * Questa classe non fa nulla: in pratica restituisce il codice catastale presupponendo che
 * esso sia già all'interno del parametro passato come nome della città.
 */
public class NoOpCityService implements CityService{

    @Override
    public String getCadastral(String city) {
        return city.toUpperCase().concat("XXXX").substring(0, 4);
    }
}
