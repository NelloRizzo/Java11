package it.corso.fiscalcode;

import it.corso.models.PersonalData;

/**
 * Definizione del servizio per il calcolo del codice fiscale.
 */
public interface FiscalCodeService {
    /**
     * Genera il codice fiscale relativo ai dati anagrafici ottenuti in input.
     * @param data dati anagrafici.
     * @return il codice fiscale corrispondente ai dati ottenuti in input.
     */
    String generateFiscalCode(PersonalData data);
}
