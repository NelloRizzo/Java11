package it.corso.fiscalcode;

import it.corso.cities.CityService;
import it.corso.models.Gender;
import it.corso.models.PersonalData;

import java.time.LocalDate;

/**
 * Implementazione del servizio di calcolo del codice fiscale.
 */
public class FiscalCodeServiceImpl implements FiscalCodeService {
    /**
     * Servizio utilizzato per reperire il codice catastale della città di nascita.
     */
    private final CityService cityService;

    /**
     * Costruttore.
     * @param cityService servizio utilizzato per reperire il codice catastale della città di nascita.
     */
    public FiscalCodeServiceImpl(CityService cityService) {
        this.cityService = cityService;
    }

    @Override
    public String generateFiscalCode(PersonalData data) {
        final StringBuilder sb = new StringBuilder(16)
                .append(handleLastName(data.getLastName()))
                .append(handleFirstName(data.getFirstName()))
                .append(handleBirthday(data.getBirthday(), data.getGender()))
                .append(handleBirthCity(data.getBirthCity()));
        return sb.append(calculateCheckCode(sb)).toString();
    }

    private char calculateCheckCode(StringBuilder sb) {
        final int[] ODDS = {1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4,
                18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23};
        int sum = 0;
        for (int i = 0; i < 15; ++i) {
            char ch = sb.charAt(i);
            int depl = Character.isDigit(ch) ? ch - '0' : ch - 'A';
            sum += i % 2 == 0 ? ODDS[depl] : depl;
        }
        return (char) (sum % 26 + 'A');
    }

    private String handleBirthCity(String birthCity) {
        return cityService.getCadastral(birthCity);
    }

    private String handleBirthday(LocalDate birthday, Gender gender) {
        return String.format("%ty%c%02d",
                birthday,
                "ABCDEHLMPRST".charAt(birthday.getMonthValue() - 1),
                birthday.getDayOfMonth() + gender.fiscalCodeValue);
    }

    /**
     * Classe di supporto per la suddivisione di un testo in consonanti e vocali.
     */
    private static class ConsonantsVowels {
        /**
         * Le consonanti del testo.
         */
        public final StringBuilder consonants = new StringBuilder();
        /**
         * Le vocali del testo.
         */
        public final StringBuilder vowels = new StringBuilder();

        /**
         * Costruttore.
         * @param text testo da elaborare.
         */
        public ConsonantsVowels(String text) {
            text = text.toUpperCase(); // mette in maiuscolo il testo
            for (int i = 0; i < text.length(); ++i) { // lo percorre nella sua lunghezza
                char ch = text.charAt(i); // prende un carattere alla volta
                if (Character.isAlphabetic(ch)) // se si tratta di un carattere alfabetico (esclude i caratteri non alfabetici)
                    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') // se è una vocale
                        vowels.append(ch); // lo aggiunge alle vocali
                    else // altrimenti
                        consonants.append(ch); // lo aggiunge alle consonanti
            }
        }
    }

    private String handleFirstName(String firstName) {
        ConsonantsVowels cv = new ConsonantsVowels(firstName);
        if (cv.consonants.length() > 3) cv.consonants.delete(1, 2);
        return cv.consonants.append(cv.vowels.append("XXX")).substring(0, 3);
    }

    private String handleLastName(String lastName) {
        ConsonantsVowels cv = new ConsonantsVowels(lastName);
        return cv.consonants.append(cv.vowels.append("XXX")).substring(0, 3);
    }
}
