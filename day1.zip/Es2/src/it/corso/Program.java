package it.corso;

import it.corso.cities.NoOpCityService;
import it.corso.fiscalcode.FiscalCodeService;
import it.corso.fiscalcode.FiscalCodeServiceImpl;
import it.corso.models.Gender;
import it.corso.models.PersonalData;

import java.time.LocalDate;

public class Program {
    public static void calculateFiscalCode(FiscalCodeService service) {
        PersonalData data = new PersonalData("Giorgia", "Meloni", LocalDate.of(1977, 1, 15), "H501", Gender.Female);
        String fc = service.generateFiscalCode(data);
        System.out.format("Codice fiscale di %s = %s\n", data, fc);
    }

    public static void main(String[] args) {
        NoOpCityService cityService = new NoOpCityService();
        calculateFiscalCode(new FiscalCodeServiceImpl(cityService));
    }
}
