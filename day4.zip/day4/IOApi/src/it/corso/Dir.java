package it.corso;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Date;

public class Dir {

    static void printDirectory(Path path, int indent) {
        try {
            Files.list(path)
                    .forEach(f -> {
                        if (Files.isDirectory(f.toAbsolutePath())) {
                            System.out.format("%s%s\n", "\t" .repeat(indent), f.getFileName());
                            printDirectory(f.toAbsolutePath(), indent + 1);
                        } else {
                            try {
                                var attrs = Files.readAttributes(f.toAbsolutePath(), BasicFileAttributes.class);

                                System.out.format("%s%s\t%3$td-%3$tm-%3$tY %3$tH:%3$tM\n",
                                        "\t" .repeat(indent),
                                        f.getFileName(),
                                        new Date(attrs.creationTime().toMillis()));
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        Path current = Paths.get("./");
        printDirectory(current, 0);
    }
}
