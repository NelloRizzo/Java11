package it.corso;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

public class WalkOnTree {
    public static void main(String[] args) {
        Path current = Paths.get("./");
        try{
            Files.walkFileTree(current, new FileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                    System.out.format("Sto entrando in %s\n", dir);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    System.out.format("Sto visitando il file %s\n", file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                    System.out.format("Non posso visitare il file %s\n", file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    System.out.format("Sto uscendo da %s\n", dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        }catch (IOException e){
            System.err.println(e);
        }
    }
}
