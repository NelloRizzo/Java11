package it.corso;

import java.io.IOException;
import java.nio.file.*;

public class Watching {
    public static void main(String[] args) throws IOException {
        Path dir = Paths.get("./test");
        try (var ws = FileSystems.getDefault().newWatchService()) {
            var key = dir.register(ws,
                    StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_DELETE,
                    StandardWatchEventKinds.ENTRY_MODIFY
            );
            while (true) {
                try {
                    key = ws.take(); // attende la notifica da parte del servizio
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                key.pollEvents() // recupera l'elenco degli eventi notificati
                        .forEach(e -> {
                            var kind = e.kind();
                            var ev = (WatchEvent<Path>) e;
                            var name = ev.context();
                            if (kind == StandardWatchEventKinds.ENTRY_CREATE) {
                                System.out.format("Creato %s\n", name);
                            }
                            if (kind == StandardWatchEventKinds.ENTRY_DELETE) {
                                System.out.format("Eliminato %s\n", name);
                            }
                            if (kind == StandardWatchEventKinds.ENTRY_MODIFY) {
                                System.out.format("Modificato %s\n", name);
                            }
                        });
                key.reset(); // reset per effettuare un nuovo poll
            }
        }
    }
}
