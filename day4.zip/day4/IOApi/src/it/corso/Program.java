package it.corso;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static java.lang.System.out;

public class Program {
    public static void main(String[] args) throws IOException {
        Path path = Paths.get("./", "test.txt");
        Path copy = Paths.get("./", "copy.txt");
        Path moved = Paths.get("./", "moved.txt");
        Files.deleteIfExists(path);
        out.println(path);
        out.println(path.toAbsolutePath());
        out.println(path.toAbsolutePath().normalize());
        out.println(path.getFileName());
        out.println(path.getFileSystem());
        out.println(path.getParent().toAbsolutePath().normalize());
        out.println(path.toAbsolutePath().getRoot());
        out.println(path.toAbsolutePath().subpath(0, 2));

        Files.deleteIfExists(moved);
        Files.deleteIfExists(copy);
        out.format("Il file %s %s\n", path, Files.exists(path) ? "esiste" : "non esiste");
        if (!Files.exists(path)) {
            Files.createFile(path);
            Files.writeString(path, "Questo è un testo\nscritto nel file.");
            out.format("Adesso il file %s %s\n", path, Files.exists(path) ? "esiste" : "non esiste");
        }
        Files.copy(path, copy);
        out.format("la copia sta su %s e adesso %s\n", copy.toAbsolutePath().normalize(), Files.exists(copy) ? "esiste" : "non esiste");
        Files.move(copy, moved);

        out.format("Contenuto del file %s\n", moved.getFileName());
        Files.readAllLines(moved).stream().forEach(out::println);
        out.println("Contenuto della cartella corrente:");
        Files.list(Paths.get("./"))
                .forEach(out::println);

    }
}
