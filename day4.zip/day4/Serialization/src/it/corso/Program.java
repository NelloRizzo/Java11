package it.corso;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Program {
    static void saveAsCsv(String filename, List<MyData> data) {
        try (var w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename)))) {
            data.forEach(
                    d -> {
                        try {
                            w.write(String.format("%s;%d;%d\n",
                                    d.getName(), d.getAge(), d.getDate().getTime()));
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static List<MyData> loadFromCsv(String filename) {
        var result = new ArrayList<MyData>();
        try {
            Files.readAllLines(Paths.get(filename)).forEach(
                    l -> {
                        var a = l.split(";");
                        result.add(new MyData(a[0], Integer.parseInt(a[1]), new Date(Long.parseLong(a[2]))));
                    }
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    static void save(String filename, List<MyData> data) {
        try (var fs = new FileOutputStream(filename)) {
            try (var os = new ObjectOutputStream(fs)) {
                os.writeObject(data);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static List<MyData> load(String filename) {
        var result = new ArrayList<MyData>();
        try (var fs = new FileInputStream(filename)) {
            try (var is = new ObjectInputStream(fs)) {
                result = (ArrayList<MyData>) is.readObject();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    public static void main(String[] args) {
        var now = new Date();
        var a = new ArrayList<>(Arrays.asList(
                new MyData("Paperino", 50, new Date(now.getTime() + 1234567)),
                new MyData("Topolino", 55, new Date(now.getTime() - 1234567)),
                new MyData("Paperone", 70, new Date(now.getTime() - 15151235))
        ));
        a.forEach(System.out::println);
        saveAsCsv("test.txt", a);
        System.out.println("Dati recuperati:");
        loadFromCsv("test.txt").forEach(System.out::println);
        System.out.println("Salvataggio su file");
        save("test.save", a);
        System.out.println("Dati recuperati dal file test.save:");
        load("test.save").forEach(System.out::println);
    }
}
