import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Program {

    private static final String RESOURCE = "https://jsonplaceholder.typicode.com/posts";

    public static void urlConnection(String[] args) throws IOException {
        var url = new URL(RESOURCE);
        var conn = url.openConnection();
        try (var s = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            s.lines().forEach(System.out::println);
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        var request = HttpRequest.newBuilder(URI.create(RESOURCE)).build();
        System.out.println("Invio della richiesta...");
        var response = client.send(request, HttpResponse.BodyHandlers.ofLines());
        System.out.format("Risposta ottenuta. Codice del server: %d\n", response.statusCode());

        System.out.println("Invio della richiesta asincrona...");
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenAccept(System.out::println)
        ;
        System.out.println("L'applicazione continua anche se la richiesta non è stata completata... ");
        System.in.read();
    }
}
