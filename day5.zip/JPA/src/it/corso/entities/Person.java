package it.corso.entities;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "people")
public class Person {
	private String name;
	private String surname;
	private long id;
	
	private Set<PhoneNumber> phones = new HashSet<>();

	@OneToMany
	public Set<PhoneNumber> getPhones() {
		return phones;
	}

	public void setPhones(Set<PhoneNumber> phones) {
		this.phones = phones;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name = "firstName", columnDefinition = "VARCHAR(20)")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "lastName", columnDefinition = "VARCHAR(20)")
	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Person() {
	}

	public Person(String name, String surname, long id) {
		this.name = name;
		this.surname = surname;
		this.id = id;
	}

	@Override
	public String toString() {
		return String.format("Person [name=%s, surname=%s, id=%s, phones=%s]", name, surname, id, phones);
	}
}
