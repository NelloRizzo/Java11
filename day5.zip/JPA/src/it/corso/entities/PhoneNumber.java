package it.corso.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "phones")
public class PhoneNumber {
	private String number;
	private long id;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}

	public String getNumber() {
		return number;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public PhoneNumber() {
	}

	public PhoneNumber(String number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return String.format("PhoneNumber [number=%s]", number);
	}

}
