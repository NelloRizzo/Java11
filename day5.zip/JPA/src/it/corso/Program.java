package it.corso;

import it.corso.entities.Person;
import it.corso.entities.PhoneNumber;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Program {

	public static void main(String[] args) {
		try (EntityManagerFactory emf = Persistence.createEntityManagerFactory("PeoplePU")) {
			try (EntityManager em = emf.createEntityManager()) {
				var archimede = new Person("Archimede", "Pitagorico", 0);
				var paperone = new Person("Paperon", "De' Paperoni", 0);
				var paperino = new Person("Paperino", "Paolino", 0);
				
				var t = em.getTransaction();
				t.begin();

				var n1 = new PhoneNumber("123456"); em.persist(n1);
				archimede.getPhones().add(n1);
				var n2 = new PhoneNumber("1233425456"); em.persist(n2);
				paperino.getPhones().add(n2);
				var n3 = new PhoneNumber("12324528746456"); em.persist(n3);
				archimede.getPhones().add(n3);
				var n4 = new PhoneNumber("1758354723456"); em.persist(n4);
				paperone.getPhones().add(n4);
				
				em.persist(archimede);
				em.persist(paperone);
				em.persist(paperino);
				
				var first = em.find(Person.class, 1);
				if (first != null) System.out.println(first);
				t.commit();
//				em.close();
//				emf.close();
			}
		}
	}

}
