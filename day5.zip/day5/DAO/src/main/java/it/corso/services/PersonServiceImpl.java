package it.corso.services;

import it.corso.dao.PersonDao;
import it.corso.entities.Person;

public class PersonServiceImpl implements PersonService {
    final PersonDao dao;

    public PersonServiceImpl(PersonDao dao) {
        this.dao = dao;
    }

    @Override
    public void create(Person p) {
        // controllo della validità di business
        // esecuzione delle operazioni di gestione della fase di creazione
        dao.create(p);
    }

    @Override
    public Person get(long id) {
        try {
            return dao.read(id);
        } catch (Exception e) {
            return null;
        }
    }
}
