package it.corso.dao;

import it.corso.entities.Person;

public interface PersonDao {
    // create -> INSERT
    void create(Person p);
    // read -> SELECT
    Person read(long id);
    // update -> UPDATE
    void update(long id, Person p);
    // delete -> DELETE
    void delete(long id);
}
