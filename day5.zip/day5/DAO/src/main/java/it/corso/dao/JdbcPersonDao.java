package it.corso.dao;

import it.corso.entities.Person;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcPersonDao implements PersonDao {
    final Connection connection;

    final String SELECT = "SELECT name, surname FROM people WHERE";


    public JdbcPersonDao(String url, String user, String pwd) {
        try {
            connection = DriverManager.getConnection(url, user, pwd);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Person p) {
    }

    @Override
    public Person read(long id) {
        try (var smt = connection.createStatement()) {
            var rs = smt.executeQuery(SELECT);
            return new Person(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("surname"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(long id, Person p) {

    }

    @Override
    public void delete(long id) {

    }
}
