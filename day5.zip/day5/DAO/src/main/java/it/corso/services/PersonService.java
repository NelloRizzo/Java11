package it.corso.services;

import it.corso.entities.Person;

public interface PersonService {
    void create(Person p);
    Person get(long id);
}
