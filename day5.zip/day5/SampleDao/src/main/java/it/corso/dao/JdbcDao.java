package it.corso.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class JdbcDao<T> implements Dao<T>, AutoCloseable {

    private final Connection connection;

    public JdbcDao(String url, String username, String password) throws SQLException {
        connection = DriverManager.getConnection(url, username, password);
    }

    @Override
    public void close() throws Exception {
        connection.close();
    }

    protected abstract String getInsertCommand(T entity);
    @Override
    public void create(T entity) {
        try (var smt = connection.createStatement()) {
            // esegue il comando insert per prendere la entity e inserira sul database
            smt.execute(getInsertCommand(entity));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected abstract String getSelectByIdStatement(long id);

    protected abstract T map(ResultSet rs);
    @Override
    public T read(long id) {
        try (var smt = connection.createStatement()) {
            // esegue il comando select per recuperare una sola entità
            var rs = smt.executeQuery(getSelectByIdStatement(id));
            if (rs.next())
                return map(rs); // qui va restituita l'entità
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected abstract String getSelectAllStatement();
    @Override
    public List<T> readAll() {
        try (var smt = connection.createStatement()) {
            // esegue il comando select per recuperare una sola entità
            var rs = smt.executeQuery(getSelectAllStatement());
            var result = new ArrayList<T>();
            while (rs.next())
                result.add(map(rs));
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void update(long id, T entity) {

    }

    @Override
    public void delete(long id) {

    }
}
