package it.corso.services;

import it.corso.dao.PersonDao;
import it.corso.entities.Person;
import it.corso.entities.Phone;

import java.util.List;

public class PeopleServiceImpl implements  PeopleService{
    private final PersonDao personDao;

    public PeopleServiceImpl(PersonDao personDao){
        this.personDao = personDao;
    }

    @Override
    public void addPerson(Person p) {
        // validazione del dato Person arrivato in input...
        personDao.create(p);
    }

    @Override
    public List<Person> getPeople() {
        return personDao.readAll();
    }

    @Override
    public void deletePerson(long id) {

    }

    @Override
    public void updatePerson(long id, Person p) {

    }

    @Override
    public void addPhone(long personId, Phone phone) {

    }

    @Override
    public void deletePhone(long phoneId) {

    }
}
