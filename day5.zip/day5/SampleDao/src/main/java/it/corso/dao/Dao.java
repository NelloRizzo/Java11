package it.corso.dao;

import java.util.List;

public interface Dao<T> {
    void create(T entity);
    T read(long id);
    List<T> readAll();
    void update(long id, T entity);
    void delete(long id);
}
