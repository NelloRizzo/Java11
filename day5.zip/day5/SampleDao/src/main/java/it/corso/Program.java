package it.corso;

import it.corso.dao.JdbcPersonDao;
import it.corso.services.PeopleServiceImpl;

import java.sql.SQLException;

public class Program {

    public static void main(String[] args) throws SQLException {
        var dao = new JdbcPersonDao("jdbc:mysql://localhost:3307/java11", "root", "");
        var service = new PeopleServiceImpl(dao);
        service.getPeople().forEach(System.out::println);
    }
}
