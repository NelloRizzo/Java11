package it.corso.dao;

import it.corso.entities.Person;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class JdbcPersonDao extends JdbcDao<Person> implements PersonDao {
    public JdbcPersonDao(String url, String username, String password) throws SQLException {
        super(url, username, password);
    }

    @Override
    protected String getInsertCommand(Person entity) {
        return null;
    }

    @Override
    protected String getSelectByIdStatement(long id) {
        return String.format("SELECT id, name, surname FROM people WHERE id = %d", id);
    }

    @Override
    protected Person map(ResultSet rs) {
        try {
            return new Person(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("surname"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected String getSelectAllStatement() {
        return String.format("SELECT id, name, surname FROM people");
    }

    @Override
    public List<Person> getByName(String name) {
        return null;
    }
}
