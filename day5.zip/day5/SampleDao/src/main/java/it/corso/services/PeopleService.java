package it.corso.services;

import it.corso.entities.Person;
import it.corso.entities.Phone;

import java.util.List;

public interface PeopleService {
    void addPerson(Person p);
    List<Person> getPeople();
    void deletePerson(long id);
    void updatePerson(long id, Person p);
    void addPhone(long personId, Phone phone);
    void deletePhone(long phoneId);
}
