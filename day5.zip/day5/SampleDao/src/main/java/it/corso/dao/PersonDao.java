package it.corso.dao;

import it.corso.entities.Person;

import java.util.List;

public interface PersonDao extends Dao<Person> {
    List<Person> getByName(String name);
}
