package it.corso.dao;

import it.corso.entities.Phone;

public interface PhoneDao extends Dao<Phone> {
}
