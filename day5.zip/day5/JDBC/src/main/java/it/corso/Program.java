package it.corso;

import java.sql.*;

public class Program {
    static final String jdbc_mysql_url = "jdbc:mysql://localhost:3307/test";
    static final String jdbc_sqlserver_url = "jdbc:sqlserver://127.0.0.1\\sqlexpress;integratedSecurity=true;databaseName=Test";
    static final String jdbc_postgresql_url = "jdbc:postgresql://localhost/test?currentSchema=public";
    static final String mysql_username = "root";
    static final String postgresql_username = "postgres";
    static final String sqlserver_username = "sa";
    static final String mysql_password = "";
    static final String sqlserver_password = "";
    static final String postgresql_password = "password";

    static final String GET_ALL_PEOPLE =
            "SELECT name, surname FROM people";

    static class Person {
        final String name;
        final String surname;

        public Person(String name, String surname) {
            this.name = name;
            this.surname = surname;
        }

        @Override
        public String toString() {
            return String.format("%s %s", name, surname);
        }
    }

    public static void main(String[] args) {
//        try (Connection conn = DriverManager.getConnection(jdbc_mysql_url, mysql_username, mysql_password)) {
        try (Connection conn = DriverManager.getConnection(jdbc_postgresql_url, postgresql_username, postgresql_password)) {
            Statement smt = conn.createStatement();

            ResultSet rs = smt.executeQuery(GET_ALL_PEOPLE);
            while (rs.next()) { // accede al prossimo record e restituisce false se abbiamo raggiunto la fine
                var p = new Person(
                        rs.getString("name"),
                        rs.getString(2));
                System.out.println(p);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
